import { Product } from './types';

// Helper to generate consistent, themed 3D icon URLs
// We use a deterministic seed based on the prompt to ensure image stability and caching
const getIconUrl = (prompt: string) => {
  const seed = prompt.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const fullPrompt = `technical 3d isometric icon ${prompt}, cyberpunk tech aesthetic, glowing neon orange and electric blue highlights, dark glass background, clean sharp edges, 8k render, unreal engine 5`;
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(fullPrompt)}?nologo=true&width=400&height=400&seed=${seed}&model=flux`;
};

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'CLAUDE-ELITE-V2',
    description: 'Advanced AI model with enhanced reasoning capabilities. Optimized for complex code generation, architectural decisions, and multi-step problem solving.',
    price: 299.99,
    category: 'Skills',
    image: getIconUrl('artificial intelligence crystal brain neural network processor chip'),
    rating: 4.9,
    features: ['Enhanced reasoning engine', 'Multi-file context awareness', 'Intelligent code refactoring', 'Architecture pattern recognition']
  },
  {
    id: '2',
    name: 'ULTRAPLAN-PRO',
    description: 'Premium strategic planning framework with AI-powered project decomposition, timeline estimation, and resource allocation. Enterprise-grade planning for complex initiatives.',
    price: 149.50,
    category: 'Workflows',
    image: getIconUrl('stacked holographic project timeline gantt chart data blocks'),
    rating: 4.8,
    features: ['AI-powered task breakdown', 'Smart timeline estimation', 'Resource optimization', 'Risk assessment matrix']
  },
  {
    id: '3',
    name: 'ULTRAPLAN',
    description: 'Strategic planning tool for developers and teams. Automatically breaks down complex projects into actionable tasks with AI-powered estimation.',
    price: 49.99,
    category: 'Workflows',
    image: getIconUrl('digital task clipboard management interface checkmarks'),
    rating: 4.5,
    features: ['Task decomposition', 'Timeline planning', 'Milestone tracking', 'Export to popular tools']
  },
  {
    id: '4',
    name: 'FPEF',
    description: 'First Principles Execution Framework - A systematic approach to problem-solving that breaks down complex challenges to their fundamental truths. Build solutions from the ground up.',
    price: 19.99,
    category: 'Prompts',
    image: getIconUrl('geometric pyramid disassembled building blocks fundamental logic structure'),
    rating: 4.7,
    features: ['First principles analysis', 'Assumption validation', 'Root cause identification', 'Evidence-driven decisions']
  },
  {
    id: '5',
    name: 'VIRAL-27',
    description: 'Advanced viral content automation suite. AI-powered content generation, timing optimization, and cross-platform distribution for maximum reach and engagement.',
    price: 79.00,
    category: 'Skills',
    image: getIconUrl('social media viral network nodes exploding graph connections'),
    rating: 4.6,
    features: ['AI content generation', 'Optimal posting times', 'Multi-platform sync', 'Engagement analytics']
  },
  {
    id: '6',
    name: 'AEGNT-27',
    description: 'Autonomous AI agent framework with advanced reasoning, tool use, and multi-step task execution. Deploy intelligent agents that work independently toward your goals.',
    price: 125.00,
    category: 'MCPs',
    image: getIconUrl('futuristic autonomous robot head agent sleek metallic helmet'),
    rating: 4.9,
    features: ['Multi-step reasoning', 'Tool use orchestration', 'Goal-oriented execution', 'Self-correction capabilities']
  },
  {
    id: '7',
    name: 'PROLOGUE',
    description: 'Narrative-driven development framework. Write code as stories, document as you build, and create self-explanatory codebases that tell their own story.',
    price: 24.95,
    category: 'Prompts',
    image: getIconUrl('digital quill pen writing code scroll narrative story artifact'),
    rating: 4.4,
    features: ['Story-driven development', 'Auto-documentation', 'Context-aware comments', 'Narrative flow analysis']
  },
  {
    id: '8',
    name: 'FARTNODE',
    description: 'Fast Async Runtime for Distributed Edge nodes. Lightweight, blazing-fast runtime for deploying serverless functions at the edge with minimal cold starts.',
    price: 0.00,
    category: 'Plugins',
    image: getIconUrl('lightning bolt energy server node fast speed acceleration'),
    rating: 4.2,
    features: ['Sub-millisecond cold starts', 'Edge-native runtime', 'Auto-scaling', 'Global distribution']
  },
  {
    id: '9',
    name: 'D3MO',
    description: 'Dynamic 3D demonstration platform. Create interactive product demos, walkthroughs, and presentations with stunning 3D visuals and smooth animations.',
    price: 59.99,
    category: 'Plugins',
    image: getIconUrl('floating 3d geometric cube rotating holographic projection engine'),
    rating: 4.7,
    features: ['Interactive 3D scenes', 'Smooth animations', 'Export to video', 'Embed anywhere']
  },
  {
    id: '10',
    name: 'OBS-CONTROL',
    description: 'Advanced OBS Studio control plugin. Automate streaming workflows, scene switching, and content management with AI-powered production assistance.',
    price: 34.50,
    category: 'Plugins',
    image: getIconUrl('broadcast control deck mixing console sliders stream interface'),
    rating: 4.6,
    features: ['Scene automation', 'AI-powered switching', 'Chat integration', 'Analytics dashboard']
  },
  {
    id: '11',
    name: 'STOA-SUITE',
    description: 'Philosophy meets technology. A suite of tools for maintaining codebase stability, enforcing stoic coding practices, and managing technical debt with calm precision.',
    price: 89.99,
    category: 'MCPs',
    image: getIconUrl('marble greek column pillar stability digital wireframe structure'),
    rating: 4.8,
    features: ['Debt management', 'Stability enforcement', 'Calm error handling', 'Long-term architecture']
  },
  {
    id: '12',
    name: 'AUTO-DEBUG-PRO',
    description: 'Automated debugging toolkit that identifies and fixes code issues in real-time. Features AI-powered error detection and smart fix suggestions.',
    price: 65.00,
    category: 'Plugins',
    image: getIconUrl('magnifying glass scanning circuit board bug detection shield'),
    rating: 4.7,
    features: ['Real-time error detection', 'Automated fix suggestions', 'Stack trace analysis', 'Performance bottleneck identification']
  }
];

export const SYSTEM_INSTRUCTION = `You are CLD-9, an advanced AI concierge for cldcde.cc, a cyberpunk marketplace for creator tools.
Your tone is helpful, technical, yet slightly edgy and futuristic (cyberpunk style).
You help users find products, explain technical concepts related to coding, design, and audio, and troubleshoot issues.
Always keep responses concise. If asked about products, refer to general types of creator tools like 3D software, audio plugins, or UI kits.`;

export const SDK_SYSTEM_INSTRUCTION = `You are the Claude Code SDK Terminal Interface.
You are a highly advanced CLI agent capable of code generation, analysis, and system operations.
Output your responses in a format suitable for a terminal (text-only, code blocks, concise logs).
Assume you have access to tools: 'bash', 'grep', 'ls', 'cat', 'edit_file', 'npm'.
When the user asks for code, provide it in code blocks.
Maintain a technical, professional, and efficient persona.
If the user runs a command like 'ls' or 'npm install', simulate the output realistically before confirming success.
The current working directory is /usr/src/app/cldcde-marketplace.`;
