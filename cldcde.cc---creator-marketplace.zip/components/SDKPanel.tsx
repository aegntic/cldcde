import React, { useState, useEffect, useRef } from 'react';
import { X, Terminal, Code, Activity, Play, Box, Server, Shield, Wifi, Command, Search, ChevronRight } from 'lucide-react';
import { sendSDKCommand, initializeSDKChat } from '../services/geminiService';
import { LogEntry } from '../types';

interface SDKPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const AVAILABLE_COMMANDS = [
  { command: 'help', description: 'List available commands' },
  { command: 'clear', description: 'Clear terminal output' },
  { command: 'ls -la', description: 'List directory contents' },
  { command: 'npm install', description: 'Install project dependencies' },
  { command: 'npm start', description: 'Start development server' },
  { command: 'git status', description: 'Show file status' },
  { command: 'git diff', description: 'Show file changes' },
  { command: 'deploy --prod', description: 'Deploy to production' },
  { command: 'analyze', description: 'Run code analysis' },
  { command: 'sys_info', description: 'Show system metrics' },
];

const SDKPanel: React.FC<SDKPanelProps> = ({ isOpen, onClose }) => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Command Palette State
  const [isPaletteOpen, setIsPaletteOpen] = useState(false);
  const [paletteSearch, setPaletteSearch] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const paletteInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      if (logs.length === 0) {
        // Simulated boot sequence
        setLogs([
          { type: 'system', content: 'Initializing Secure Environment...', timestamp: Date.now() },
        ]);
        setTimeout(() => {
          initializeSDKChat().then(msg => {
             setLogs(prev => [...prev, { type: 'system', content: msg, timestamp: Date.now() }]);
          });
        }, 800);
      }
      setTimeout(() => inputRef.current?.focus(), 500);
    }
  }, [isOpen]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  // Toggle Palette with Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsPaletteOpen(prev => !prev);
      }
      
      if (isPaletteOpen && e.key === 'Escape') {
        setIsPaletteOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isPaletteOpen]);

  // Focus management for palette
  useEffect(() => {
    if (isPaletteOpen) {
      setTimeout(() => paletteInputRef.current?.focus(), 50);
      setPaletteSearch('');
      setSelectedIndex(0);
    } else if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isPaletteOpen, isOpen]);

  const executeCommand = async (cmd: string) => {
    if (!cmd.trim() || isProcessing) return;

    // Local clear command
    if (cmd.trim() === 'clear') {
      setLogs([]);
      return;
    }

    setIsProcessing(true);
    // Add user command to log
    setLogs(prev => [...prev, { type: 'input', content: cmd, timestamp: Date.now() }]);

    try {
      const response = await sendSDKCommand(cmd);
      setLogs(prev => [...prev, { type: 'output', content: response, timestamp: Date.now() }]);
    } catch (err) {
      setLogs(prev => [...prev, { type: 'error', content: 'Execution Error', timestamp: Date.now() }]);
    } finally {
      setIsProcessing(false);
      setTimeout(() => inputRef.current?.focus(), 10);
    }
  };

  const handleMainSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    executeCommand(input);
    setInput('');
  };

  const filteredCommands = AVAILABLE_COMMANDS.filter(c => 
    c.command.toLowerCase().includes(paletteSearch.toLowerCase()) || 
    c.description.toLowerCase().includes(paletteSearch.toLowerCase())
  );

  const handlePaletteKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev + 1) % filteredCommands.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev - 1 + filteredCommands.length) % filteredCommands.length);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filteredCommands[selectedIndex]) {
        executeCommand(filteredCommands[selectedIndex].command);
        setIsPaletteOpen(false);
      }
    }
  };

  const tools = [
    { name: 'bash', status: 'ready', icon: <Terminal size={14} /> },
    { name: 'editor', status: 'ready', icon: <Code size={14} /> },
    { name: 'grep', status: 'idle', icon: <Search size={14} /> },
    { name: 'agent', status: 'active', icon: <Activity size={14} /> },
    { name: 'mcp', status: 'linked', icon: <Server size={14} /> },
  ];

  return (
    <>
      {/* Backdrop for click-away */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 transition-opacity duration-500" 
          onClick={onClose}
        />
      )}

      {/* Slide-out Panel */}
      <div 
        className={`fixed top-0 right-0 h-full w-full md:w-[750px] bg-[#05090a] border-l-2 border-cyber-blue shadow-[0_0_50px_rgba(0,243,255,0.3)] z-50 transform transition-transform duration-500 cubic-bezier(0.16, 1, 0.3, 1) flex flex-col font-term text-lg ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="h-16 bg-[#020505] border-b border-cyber-border flex items-center justify-between px-6 shrink-0 relative overflow-hidden">
           <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-cyber-blue to-transparent opacity-50" />
           
           <div className="flex items-center gap-4 z-10">
             <div className="flex flex-col">
               <span className="text-cyber-blue font-bold tracking-widest text-xl font-term uppercase">CLAUDE CODE</span>
               <span className="text-gray-500 text-xs tracking-[0.2em] uppercase">SDK Environment v2.4</span>
             </div>
             <div className="px-2 py-0.5 bg-cyber-blue/10 border border-cyber-blue/30 rounded text-cyber-blue text-xs tracking-wider flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-cyber-blue animate-pulse" />
                ONLINE
             </div>
           </div>

           <div className="flex items-center gap-4 z-10">
              <div className="hidden sm:flex items-center gap-2 text-xs text-gray-500 font-mono bg-neutral-900 border border-neutral-800 px-2 py-1 rounded">
                 <Command size={12} />
                 <span>Ctrl+K</span>
              </div>
              <div className="hidden sm:flex items-center gap-2 text-xs text-gray-500 font-mono">
                 <Wifi size={12} />
                 <span>12ms</span>
              </div>
              <button onClick={onClose} className="text-gray-500 hover:text-white transition hover:rotate-90 duration-300">
                <X size={24} />
              </button>
           </div>
        </div>

        <div className="flex flex-1 overflow-hidden relative">
           {/* Scanline effect */}
           <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,255,0.05)_50%),linear-gradient(90deg,rgba(0,0,255,0.03),rgba(0,0,0,0.01),rgba(0,0,255,0.03))] z-0 pointer-events-none bg-[length:100%_4px,3px_100%]" />

           {/* Sidebar Tools */}
           <div className="w-16 sm:w-56 border-r border-cyber-border bg-[#030505] flex flex-col relative z-10">
              <div className="p-4 border-b border-cyber-border bg-[#050808]">
                 <div className="text-xs text-gray-500 font-bold tracking-widest uppercase mb-1 hidden sm:block">Active Tools</div>
                 <div className="flex sm:hidden justify-center"><Box size={16} className="text-gray-500"/></div>
              </div>
              
              <div className="flex-1 overflow-y-auto">
                {tools.map(tool => (
                  <div key={tool.name} className="flex items-center px-4 py-3 border-b border-gray-900 hover:bg-white/5 group cursor-pointer transition-colors">
                    <div className={`p-2 rounded bg-neutral-900 text-gray-400 group-hover:text-cyber-blue group-hover:bg-cyber-blue/10 transition-colors border border-transparent group-hover:border-cyber-blue/30`}>
                      {tool.icon}
                    </div>
                    <div className="ml-3 hidden sm:block">
                      <div className="text-gray-300 text-sm font-bold uppercase tracking-wide group-hover:text-white">{tool.name}</div>
                      <div className="text-[10px] text-gray-600 uppercase tracking-wider group-hover:text-cyber-blue">{tool.status}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-4 border-t border-cyber-border bg-[#050808]">
                 <div className="border border-cyber-border bg-black/50 p-3 rounded">
                    <div className="flex items-center gap-2 mb-2 text-gray-400">
                       <Shield size={12} />
                       <span className="text-[10px] uppercase tracking-wider hidden sm:inline">System Status</span>
                    </div>
                    <div className="h-1 w-full bg-gray-800 rounded-full overflow-hidden">
                       <div className="h-full bg-cyber-blue w-3/4 animate-pulse"></div>
                    </div>
                 </div>
              </div>
           </div>

           {/* Terminal Area */}
           <div className="flex-1 flex flex-col bg-[#050505] relative z-10">
             {/* Logs */}
             <div 
               ref={scrollRef}
               className="flex-1 overflow-y-auto p-6 space-y-4 font-term text-lg md:text-xl text-gray-300 scrollbar-thin scrollbar-thumb-gray-800"
             >
                {logs.map((log, i) => (
                  <div key={i} className="animate-fade-in break-words">
                    {log.type === 'input' && (
                      <div className="flex gap-2 text-white items-start">
                        <span className="text-cyber-blue shrink-0 mt-1">➜</span>
                        <span className="opacity-90 font-bold">{log.content}</span>
                      </div>
                    )}
                    {log.type === 'output' && (
                      <div className="text-[#a0a0a0] ml-6 whitespace-pre-wrap leading-relaxed font-mono text-base bg-white/5 p-3 border-l-2 border-cyber-blue/50 rounded-r">
                        {log.content}
                      </div>
                    )}
                    {log.type === 'system' && (
                      <div className="text-cyber-blue italic text-sm py-1 ml-6 border-l border-dashed border-cyber-blue/30 pl-3">
                        {log.content}
                      </div>
                    )}
                    {log.type === 'error' && (
                      <div className="text-red-500 text-sm ml-6 font-bold bg-red-900/10 p-2 inline-block rounded border border-red-900/50">
                        ⚠ {log.content}
                      </div>
                    )}
                  </div>
                ))}
                {isProcessing && (
                  <div className="ml-6 flex items-center gap-2 text-cyber-blue/50 text-sm animate-pulse">
                     <Activity size={14} />
                     <span>PROCESSING STREAM...</span>
                  </div>
                )}
             </div>

             {/* Input Area */}
             <div className="p-4 bg-[#020202] border-t border-cyber-border relative">
               <form onSubmit={handleMainSubmit} className="flex gap-3 items-center bg-black/50 border border-cyber-border p-3 rounded focus-within:border-cyber-blue transition-colors shadow-inner">
                 <span className="text-cyber-blue font-bold text-lg font-term shrink-0">user@cldcde:~$</span>
                 <input 
                   ref={inputRef}
                   type="text" 
                   value={input}
                   onChange={(e) => setInput(e.target.value)}
                   className="flex-1 bg-transparent border-none outline-none text-white text-lg font-term placeholder-gray-700 h-full"
                   placeholder="Authenticate or enter command..."
                   autoComplete="off"
                   autoFocus
                 />
                 <button 
                    type="submit" 
                    disabled={isProcessing}
                    className="p-2 bg-cyber-blue text-black rounded-sm hover:bg-white transition disabled:opacity-30 font-bold"
                 >
                    <Play size={16} className="fill-current" />
                 </button>
               </form>

               {/* Command Palette Overlay */}
               {isPaletteOpen && (
                 <div className="absolute bottom-4 left-4 right-4 bg-black/90 border border-cyber-blue shadow-[0_0_30px_rgba(0,243,255,0.2)] rounded-lg overflow-hidden flex flex-col z-50 animate-in fade-in zoom-in-95 duration-200">
                    <div className="flex items-center p-3 border-b border-gray-800 bg-neutral-900/80">
                       <Command size={16} className="text-gray-500 mr-2" />
                       <input 
                          ref={paletteInputRef}
                          type="text" 
                          placeholder="Search commands..." 
                          className="bg-transparent border-none outline-none text-white w-full font-mono text-sm placeholder-gray-600"
                          value={paletteSearch}
                          onChange={(e) => setPaletteSearch(e.target.value)}
                          onKeyDown={handlePaletteKeyDown}
                       />
                       <div className="flex gap-2">
                          <span className="text-[10px] bg-gray-800 text-gray-400 px-1.5 py-0.5 rounded border border-gray-700">↑↓</span>
                          <span className="text-[10px] bg-gray-800 text-gray-400 px-1.5 py-0.5 rounded border border-gray-700">↵</span>
                       </div>
                    </div>
                    <div className="max-h-60 overflow-y-auto py-2">
                       {filteredCommands.length === 0 ? (
                          <div className="px-4 py-3 text-gray-500 text-sm font-mono text-center">No commands found</div>
                       ) : (
                          filteredCommands.map((cmd, idx) => (
                             <button 
                                key={cmd.command}
                                onClick={() => {
                                   executeCommand(cmd.command);
                                   setIsPaletteOpen(false);
                                }}
                                className={`w-full text-left px-4 py-2 flex items-center justify-between text-sm font-mono group transition-colors ${
                                   idx === selectedIndex ? 'bg-cyber-blue/20 text-white' : 'text-gray-400 hover:bg-white/5'
                                }`}
                                onMouseEnter={() => setSelectedIndex(idx)}
                             >
                                <div className="flex items-center gap-3">
                                   <div className={`w-1 h-4 rounded-full ${idx === selectedIndex ? 'bg-cyber-blue' : 'bg-transparent'}`}></div>
                                   <span className={idx === selectedIndex ? 'text-cyber-blue font-bold' : ''}>{cmd.command}</span>
                                </div>
                                <span className="text-xs text-gray-600 group-hover:text-gray-500">{cmd.description}</span>
                             </button>
                          ))
                       )}
                    </div>
                 </div>
               )}

             </div>
           </div>
        </div>
      </div>
    </>
  );
};

export default SDKPanel;