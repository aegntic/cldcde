import React, { useState, useEffect, useContext, createContext } from 'react';
import { HashRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, User as UserIcon, LogOut, Menu, X, Trash2, Plus, Minus, Search, LayoutDashboard, CreditCard, ShieldCheck, Terminal, Cpu, Zap, Download } from 'lucide-react';
import { Product, CartItem, User } from './types';
import { MOCK_PRODUCTS } from './constants';
import AIChat from './components/AIChat';
import SDKPanel from './components/SDKPanel';

// --- Contexts ---

interface AppContextType {
  cart: CartItem[];
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, delta: number) => void;
  clearCart: () => void;
  user: User | null;
  login: (role: 'user' | 'admin') => void;
  logout: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (v: boolean) => void;
  isSDKOpen: boolean;
  setIsSDKOpen: (v: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useAppContext must be used within AppProvider");
  return context;
};

// --- Utilities ---

const downloadData = (data: unknown, filename: string) => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

// --- Components ---

const Navbar: React.FC = () => {
  const { cart, user, logout, setIsCartOpen, setIsSDKOpen } = useAppContext();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <nav className="fixed top-0 left-0 w-full z-40 bg-cyber-dark/90 backdrop-blur-md border-b border-cyber-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-2">
            <Link to="/" className="text-4xl font-term font-bold text-cyber-neon tracking-widest hover:text-cyber-blue hover:shadow-blue transition-all duration-300 flex items-center text-shadow-neon">
              CLDCDE<span className="text-white">.CC</span>
            </Link>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8 font-term text-xl tracking-wider">
              <Link to="/" className="hover:text-cyber-blue transition text-gray-300 hover:border-b-2 hover:border-cyber-blue pb-1">MARKETPLACE</Link>
              {user?.role === 'admin' && (
                <Link to="/admin" className="hover:text-cyber-blue transition text-gray-300 hover:border-b-2 hover:border-cyber-blue pb-1">DASHBOARD</Link>
              )}
            </div>
          </div>

          <div className="flex items-center gap-6">
            <button 
              onClick={() => setIsSDKOpen(true)}
              className="hidden md:flex items-center gap-2 px-4 py-2 bg-neutral-900 border border-cyber-blue/30 rounded text-xs font-mono text-cyber-blue hover:bg-cyber-blue/10 hover:shadow-blue transition-all group"
            >
               <Terminal size={14} className="group-hover:animate-pulse" />
               <span className="font-bold">LAUNCH SDK</span>
            </button>

            <button onClick={() => setIsCartOpen(true)} className="relative text-gray-300 hover:text-cyber-blue transition group">
              <ShoppingCart size={22} />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-cyber-blue text-black text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full shadow-blue">
                  {cartCount}
                </span>
              )}
            </button>
            
            {user ? (
              <div className="hidden md:flex items-center gap-4">
                 <div className="flex flex-col items-end">
                    <span className="text-xs font-bold text-white">{user.name.toUpperCase()}</span>
                    <span className="text-[10px] font-mono text-cyber-blue">{user.role.toUpperCase()}</span>
                 </div>
                 <button onClick={logout} className="text-gray-500 hover:text-red-500 transition">
                   <LogOut size={20} />
                 </button>
              </div>
            ) : (
              <Link to="/login" className="hidden md:flex items-center gap-2 px-5 py-2 border border-cyber-neon bg-cyber-neon/10 rounded text-cyber-neon text-xs font-bold font-mono hover:bg-cyber-neon hover:text-black transition shadow-neon-strong">
                <UserIcon size={14} /> SIGN IN
              </Link>
            )}

            <div className="md:hidden">
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="text-gray-300">
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden bg-black border-b border-cyber-border">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 font-term text-xl">
            <Link to="/" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2 text-gray-300 hover:text-cyber-blue">MARKET</Link>
            {user?.role === 'admin' && (
              <Link to="/admin" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2 text-gray-300 hover:text-cyber-blue">DASHBOARD</Link>
            )}
            <button onClick={() => { setIsSDKOpen(true); setMobileMenuOpen(false); }} className="block w-full text-left px-3 py-2 text-cyber-blue hover:bg-white/5 border-l-2 border-cyber-blue bg-cyber-blue/5">
               LAUNCH SDK DEMO
            </button>
            {!user && (
              <Link to="/login" onClick={() => setMobileMenuOpen(false)} className="block px-3 py-2 text-cyber-neon font-bold">SIGN IN</Link>
            )}
            {user && (
               <button onClick={() => { logout(); setMobileMenuOpen(false); }} className="block w-full text-left px-3 py-2 text-red-500">LOGOUT</button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

const CartDrawer: React.FC = () => {
  const { isCartOpen, setIsCartOpen, cart, updateQuantity, removeFromCart, clearCart } = useAppContext();
  const navigate = useNavigate();
  const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsCartOpen(false)} />
      <div className="absolute inset-y-0 right-0 max-w-full flex">
        <div className="w-screen max-w-md bg-cyber-panel border-l border-cyber-border shadow-blue-strong flex flex-col">
          <div className="flex items-center justify-between p-6 border-b border-cyber-border">
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-term font-bold text-cyber-blue tracking-wider">CART_SYSTEM</h2>
              {cart.length > 0 && (
                <button 
                  onClick={() => downloadData(cart, 'cldcde_cart_export.json')} 
                  className="text-gray-500 hover:text-cyber-blue transition" 
                  title="Export Raw Data"
                >
                  <Download size={18} />
                </button>
              )}
            </div>
            <button onClick={() => setIsCartOpen(false)} className="text-gray-400 hover:text-white">
              <X size={24} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {cart.length === 0 ? (
              <div className="text-center text-gray-500 font-mono py-10">
                [EMPTY_BUFFER]
                <br />
                Select tools to initiate.
              </div>
            ) : (
              cart.map(item => (
                <div key={item.id} className="flex gap-4 p-4 bg-neutral-900/50 border border-cyber-border rounded-lg">
                   <img src={item.image} alt={item.name} loading="lazy" className="w-20 h-20 object-cover rounded bg-neutral-800" />
                   <div className="flex-1">
                     <h3 className="text-lg font-term font-bold text-white mb-1">{item.name}</h3>
                     <p className="text-cyber-blue font-mono text-sm">${item.price.toFixed(2)}</p>
                     <div className="flex items-center gap-3 mt-3">
                        <button onClick={() => updateQuantity(item.id, -1)} className="p-1 border border-neutral-600 rounded hover:border-cyber-blue text-gray-400 hover:text-cyber-blue transition">
                          <Minus size={12} />
                        </button>
                        <span className="font-mono text-sm">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.id, 1)} className="p-1 border border-neutral-600 rounded hover:border-cyber-blue text-gray-400 hover:text-cyber-blue transition">
                          <Plus size={12} />
                        </button>
                        <button onClick={() => removeFromCart(item.id)} className="ml-auto text-red-500 hover:text-red-400">
                          <Trash2 size={16} />
                        </button>
                     </div>
                   </div>
                </div>
              ))
            )}
          </div>

          {cart.length > 0 && (
            <div className="p-6 border-t border-cyber-border bg-neutral-900/30">
              <div className="flex justify-between items-center mb-4 font-mono text-lg">
                <span className="text-gray-400">TOTAL</span>
                <span className="text-cyber-blue font-bold">${total.toFixed(2)}</span>
              </div>
              <button 
                onClick={() => {
                  setIsCartOpen(false);
                  navigate('/checkout');
                }}
                className="w-full py-4 bg-cyber-blue text-black font-bold font-term text-xl tracking-wide hover:bg-white transition flex items-center justify-center gap-2 shadow-blue"
              >
                PROCEED TO CHECKOUT
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// --- Pages ---

const Home: React.FC = () => {
  const { addToCart } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [category, setCategory] = useState<string>('All');

  const filteredProducts = MOCK_PRODUCTS.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = category === 'All' || p.category === category;
    return matchesSearch && matchesCategory;
  });

  const categories = ['All', ...Array.from(new Set(MOCK_PRODUCTS.map(p => p.category)))];

  const asciiClaude = `
  ██████╗██╗      █████╗ ██╗   ██╗██████╗ ███████╗    ██████╗ ██████╗ ██████╗ ███████╗
 ██╔════╝██║     ██╔══██╗██║   ██║██╔══██╗██╔════╝   ██╔════╝██╔═══██╗██╔══██╗██╔════╝
 ██║     ██║     ███████║██║   ██║██║  ██║█████╗     ██║     ██║   ██║██║  ██║█████╗  
 ██║     ██║     ██╔══██║██║   ██║██║  ██║██╔══╝     ██║     ██║   ██║██║  ██║██╔══╝  
 ╚██████╗███████╗██║  ██║╚██████╔╝██████╔╝███████╗   ╚██████╗╚██████╔╝██████╔╝███████╗
  ╚═════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝    ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝
`;

  const asciiMarket = `
 ███╗   ███╗ █████╗ ██████╗ ██╗  ██╗███████╗████████╗██████╗ ██╗      █████╗  ██████╗███████╗
 ████╗ ████║██╔══██╗██╔══██╗██║ ██╔╝██╔════╝╚══██╔══╝██╔══██╗██║     ██╔══██╗██╔════╝██╔════╝
 ██╔████╔██║███████║██████╔╝█████╔╝ █████╗     ██║   ██████╔╝██║     ███████║██║     █████╗  
 ██║╚██╔╝██║██╔══██║██╔══██╗██╔═██╗ ██╔══╝     ██║   ██╔═══╝ ██║     ██╔══██║██║     ██╔══╝  
 ██║ ╚═╝ ██║██║  ██║██║  ██║██║  ██╗███████╗   ██║   ██║     ███████╗██║  ██║╚██████╗███████╗
 ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝   ╚═╝   ╚═╝     ╚══════╝╚═╝  ╚═╝ ╚═════╝╚══════╝
`;

  return (
    <div className="min-h-screen pt-24 pb-10 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      {/* Hero Section */}
      <div className="mb-12 text-center py-8 md:py-16 border-b border-cyber-border relative overflow-hidden">
         <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,94,0,0.08)_0,rgba(0,0,0,0)_70%)] pointer-events-none" />
         
         <div className="relative z-10 mb-8 hidden sm:block">
            <pre className="font-mono text-[0.35rem] leading-[0.35rem] sm:text-[0.45rem] sm:leading-[0.45rem] md:text-[0.6rem] md:leading-[0.6rem] lg:text-[0.7rem] lg:leading-[0.7rem] xl:text-[0.8rem] xl:leading-[0.8rem] text-cyber-neon font-black tracking-tighter whitespace-pre overflow-x-hidden select-none opacity-90 mx-auto w-fit text-shadow-neon">
              {asciiClaude}
              {asciiMarket}
            </pre>
         </div>

         {/* Fallback Title for very small mobile screens */}
         <div className="sm:hidden relative z-10 mb-6">
            <h1 className="text-5xl font-term font-black text-white tracking-tighter uppercase text-shadow-neon">
              CLAUDE CODE
            </h1>
            <h2 className="text-3xl font-term font-black text-cyber-neon tracking-tighter uppercase mt-2 text-shadow-neon">
              MARKETPLACE
            </h2>
         </div>

         <div className="flex flex-wrap justify-center gap-4 mt-8 relative z-10">
            {['PLUGINS', 'MCPS', 'SKILLS', 'PROMPTS', 'WORKFLOWS'].map(cat => (
              <div key={cat} className="px-6 py-2 border border-cyber-blue/30 bg-black/50 backdrop-blur rounded text-cyber-blue font-mono text-sm font-bold tracking-widest hover:bg-cyber-blue hover:text-black transition cursor-pointer shadow-blue hover:shadow-blue-strong">
                {cat}
              </div>
            ))}
         </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-6 mb-8 items-center justify-between">
         <div className="flex items-center bg-neutral-900 border border-neutral-700 p-3 rounded w-full md:w-96 focus-within:border-cyber-blue focus-within:shadow-blue transition-all">
            <Search className="text-gray-500 ml-2" size={20} />
            <input 
              type="text" 
              placeholder="Search models, scripts, and tools..." 
              className="bg-transparent border-none focus:ring-0 text-white w-full ml-2 focus:outline-none placeholder-gray-600 font-mono text-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
         </div>
         <div className="flex gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-hide">
           {categories.map(cat => (
             <button 
               key={cat}
               onClick={() => setCategory(cat)}
               className={`px-4 py-2 rounded-sm text-xs font-mono font-bold whitespace-nowrap border transition-all ${
                 category === cat 
                 ? 'bg-cyber-blue text-black border-cyber-blue shadow-blue' 
                 : 'bg-transparent border-neutral-700 text-gray-400 hover:border-cyber-blue/50 hover:text-cyber-blue'
               }`}
             >
               {cat.toUpperCase()}
             </button>
           ))}
         </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredProducts.map(product => (
          <div key={product.id} className="group bg-neutral-900/40 border border-neutral-800 hover:border-cyber-blue/50 rounded-lg overflow-hidden transition-all duration-300 hover:shadow-blue hover:-translate-y-1 backdrop-blur-sm">
            <div className="relative h-64 overflow-hidden bg-black">
               <img src={product.image} alt={product.name} loading="lazy" className="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-70 group-hover:opacity-100" />
               <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-90" />
               <div className="absolute bottom-4 left-4 right-4">
                 <div className="flex justify-between items-end">
                   <span className="bg-cyber-blue/10 text-cyber-blue px-2 py-1 text-[10px] font-bold tracking-wider font-mono rounded border border-cyber-blue/30 uppercase">{product.category}</span>
                   <div className="flex text-cyber-blue text-xs gap-0.5">
                     {"★".repeat(Math.floor(product.rating))}
                   </div>
                 </div>
               </div>
            </div>
            <div className="p-5">
              <h3 className="text-2xl font-bold text-cyber-neon mb-2 font-term tracking-wide leading-none">{product.name}</h3>
              <p className="text-gray-400 text-sm mb-4 line-clamp-2 h-10 font-sans">{product.description}</p>
              
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-neutral-800">
                <span className="text-2xl font-mono text-cyber-blue tracking-tighter shadow-blue-sm drop-shadow-[0_0_5px_rgba(0,243,255,0.5)]">${product.price}</span>
                <button 
                  onClick={() => addToCart(product)}
                  className="bg-white text-black hover:bg-cyber-neon transition px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-sm flex items-center gap-2 font-mono"
                >
                  <Plus size={14} /> Add
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredProducts.length === 0 && (
         <div className="text-center py-20">
           <p className="text-gray-500 font-mono">No matching artifacts found.</p>
         </div>
      )}
      
      <div className="mt-20 border-t border-cyber-border pt-12">
        <h2 className="text-2xl font-term text-cyber-neon text-shadow-neon mb-8">FEATURED FREE & PAID</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
           {[1,2,3,4].map(i => (
             <div key={i} className="bg-neutral-900/30 border border-cyber-border p-4 rounded hover:border-cyber-blue/30 transition group">
                <div className="w-full h-32 bg-cyber-blue/5 rounded mb-3 flex items-center justify-center border border-cyber-blue/10 group-hover:bg-cyber-blue/10 transition">
                  <Zap className="text-cyber-blue opacity-50 group-hover:opacity-100 group-hover:scale-110 transition" size={32} />
                </div>
                <div className="text-xs text-cyber-blue font-mono mb-1">Free: Basic Script</div>
                <div className="text-white font-bold text-sm font-term tracking-wide">Automated Refactor</div>
             </div>
           ))}
        </div>
      </div>
    </div>
  );
};

const AdminDashboard: React.FC = () => {
  const { user } = useAppContext();
  
  if (!user || user.role !== 'admin') {
    return <div className="pt-32 text-center text-red-500 font-mono">ACCESS DENIED. PROTOCOL 403.</div>;
  }

  return (
    <div className="min-h-screen pt-24 px-4 max-w-7xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <LayoutDashboard className="text-cyber-neon" size={32} />
        <h1 className="text-4xl font-term font-bold text-cyber-neon text-shadow-neon">ADMIN_CONSOLE</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-neutral-900 p-6 border border-cyber-border rounded">
           <p className="text-gray-500 font-mono text-sm">TOTAL REVENUE</p>
           <p className="text-3xl text-cyber-blue font-bold mt-2 font-term">$12,450.00</p>
        </div>
        <div className="bg-neutral-900 p-6 border border-cyber-border rounded">
           <p className="text-gray-500 font-mono text-sm">ACTIVE USERS</p>
           <p className="text-3xl text-white font-bold mt-2 font-term">1,203</p>
        </div>
        <div className="bg-neutral-900 p-6 border border-cyber-border rounded">
           <p className="text-gray-500 font-mono text-sm">SYSTEM HEALTH</p>
           <p className="text-3xl text-green-400 font-bold mt-2 font-term">98.9%</p>
        </div>
      </div>

      <div className="bg-neutral-900 border border-cyber-border rounded overflow-hidden">
        <div className="p-4 border-b border-cyber-border bg-neutral-800/50 flex justify-between items-center">
          <h2 className="font-bold text-white font-term text-xl tracking-wide">PRODUCT_DATABASE</h2>
          <button 
            onClick={() => downloadData(MOCK_PRODUCTS, 'cldcde_product_db.json')} 
            className="flex items-center gap-2 text-xs font-mono text-cyber-blue border border-cyber-blue/30 px-3 py-1 rounded hover:bg-cyber-blue/10 transition"
          >
            <Download size={14} /> EXPORT_DATA
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-gray-400">
            <thead className="bg-neutral-800 text-gray-200 uppercase font-mono text-xs">
              <tr>
                <th className="px-6 py-3">ID</th>
                <th className="px-6 py-3">Product Name</th>
                <th className="px-6 py-3">Category</th>
                <th className="px-6 py-3">Price</th>
                <th className="px-6 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800">
              {MOCK_PRODUCTS.map(p => (
                <tr key={p.id} className="hover:bg-neutral-800/50 transition">
                  <td className="px-6 py-4 font-mono text-xs text-gray-500">#{p.id.padStart(4, '0')}</td>
                  <td className="px-6 py-4 font-medium text-white font-term text-lg">{p.name}</td>
                  <td className="px-6 py-4 text-cyber-blue">{p.category}</td>
                  <td className="px-6 py-4 text-cyber-neon font-mono">${p.price}</td>
                  <td className="px-6 py-4">
                    <span className="bg-green-900/30 text-green-400 border border-green-900 px-2 py-0.5 rounded text-xs">ACTIVE</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const Checkout: React.FC = () => {
  const { cart, clearCart } = useAppContext();
  const navigate = useNavigate();
  const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const [processing, setProcessing] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);
    setTimeout(() => {
      clearCart();
      setProcessing(false);
      alert("Purchase Successful. Assets transferred to your vault.");
      navigate('/');
    }, 2000);
  };

  if (cart.length === 0) return (
    <div className="min-h-screen pt-32 text-center">
       <h2 className="text-3xl font-term text-white mb-4">CART EMPTY</h2>
       <Link to="/" className="text-cyber-blue hover:underline font-mono">Return to Marketplace</Link>
    </div>
  );

  return (
    <div className="min-h-screen pt-24 pb-12 px-4 max-w-4xl mx-auto">
      <h1 className="text-4xl font-term font-bold text-cyber-neon text-shadow-neon mb-8">SECURE_CHECKOUT</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Form */}
        <div>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-xl font-term text-cyber-blue border-b border-gray-800 pb-2">Billing Details</h3>
              <div>
                <label className="block text-xs font-mono text-gray-500 mb-1">FULL NAME</label>
                <input required type="text" className="w-full bg-neutral-900 border border-neutral-700 p-3 rounded text-white focus:border-cyber-blue focus:shadow-blue transition outline-none" />
              </div>
              <div>
                <label className="block text-xs font-mono text-gray-500 mb-1">EMAIL ADDR</label>
                <input required type="email" className="w-full bg-neutral-900 border border-neutral-700 p-3 rounded text-white focus:border-cyber-blue focus:shadow-blue transition outline-none" />
              </div>
            </div>

            <div className="space-y-4 pt-6">
              <h3 className="text-xl font-term text-cyber-blue border-b border-gray-800 pb-2">Payment Method</h3>
              <div className="flex gap-4 mb-4">
                <button type="button" className="flex-1 py-3 border border-cyber-blue/50 bg-cyber-blue/10 text-cyber-blue rounded font-bold flex items-center justify-center gap-2 shadow-blue">
                  <CreditCard size={18} /> CARD
                </button>
                <button type="button" className="flex-1 py-3 border border-neutral-700 bg-neutral-800 text-gray-400 rounded hover:bg-neutral-700 font-bold">
                  CRYPTO
                </button>
              </div>
              <div>
                <label className="block text-xs font-mono text-gray-500 mb-1">CARD NUMBER</label>
                <input required type="text" placeholder="0000 0000 0000 0000" className="w-full bg-neutral-900 border border-neutral-700 p-3 rounded text-white focus:border-cyber-blue focus:shadow-blue transition font-mono outline-none" />
              </div>
              <div className="flex gap-4">
                 <div className="flex-1">
                   <label className="block text-xs font-mono text-gray-500 mb-1">EXPIRY</label>
                   <input required type="text" placeholder="MM/YY" className="w-full bg-neutral-900 border border-neutral-700 p-3 rounded text-white focus:border-cyber-blue focus:shadow-blue transition font-mono outline-none" />
                 </div>
                 <div className="flex-1">
                   <label className="block text-xs font-mono text-gray-500 mb-1">CVC</label>
                   <input required type="text" placeholder="123" className="w-full bg-neutral-900 border border-neutral-700 p-3 rounded text-white focus:border-cyber-blue focus:shadow-blue transition font-mono outline-none" />
                 </div>
              </div>
            </div>

            <button disabled={processing} type="submit" className="w-full mt-8 py-4 bg-cyber-neon hover:bg-white text-black font-term font-bold text-xl rounded shadow-neon transition flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed">
              {processing ? 'PROCESSING...' : `PAY $${total.toFixed(2)}`}
            </button>
            <div className="flex items-center justify-center gap-2 text-green-500 text-xs font-mono mt-4">
              <ShieldCheck size={14} /> 256-BIT ENCRYPTION SECURED
            </div>
          </form>
        </div>

        {/* Order Summary */}
        <div className="bg-neutral-900/50 p-6 rounded border border-neutral-800 h-fit shadow-blue-strong">
          <h3 className="text-xl font-term text-cyber-blue border-b border-gray-800 pb-4 mb-4">Order Summary</h3>
          <div className="space-y-4 mb-6">
            {cart.map(item => (
              <div key={item.id} className="flex justify-between items-start text-sm">
                <div>
                  <p className="text-white font-bold font-term text-lg">{item.name}</p>
                  <p className="text-gray-500 text-xs">Qty: {item.quantity}</p>
                </div>
                <p className="text-cyber-blue font-mono">${(item.price * item.quantity).toFixed(2)}</p>
              </div>
            ))}
          </div>
          <div className="border-t border-gray-800 pt-4 space-y-2 font-mono">
            <div className="flex justify-between text-gray-400 text-sm">
              <span>Subtotal</span>
              <span>${total.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-gray-400 text-sm">
              <span>Tax (Est.)</span>
              <span>$0.00</span>
            </div>
            <div className="flex justify-between text-cyber-neon text-xl font-bold pt-2 border-t border-gray-800 mt-2">
              <span>Total</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const Login: React.FC = () => {
  const { login } = useAppContext();
  const navigate = useNavigate();

  const handleLogin = (role: 'user' | 'admin') => {
    login(role);
    navigate(role === 'admin' ? '/admin' : '/');
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-cyber-blue/10 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="max-w-md w-full bg-cyber-panel border border-cyber-border p-8 rounded-lg shadow-blue-strong relative z-10 backdrop-blur-xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-term font-bold text-white mb-2 tracking-wide">IDENTIFICATION</h1>
          <p className="text-cyber-blue text-sm font-mono">Select protocol level to proceed</p>
        </div>

        <div className="space-y-4">
          <button 
            onClick={() => handleLogin('user')}
            className="w-full py-4 bg-transparent border border-neutral-600 hover:border-cyber-blue text-white font-mono rounded transition flex items-center justify-center gap-3 group"
          >
             <UserIcon className="group-hover:text-cyber-blue transition" />
             STANDARD_USER
          </button>
          
          <button 
            onClick={() => handleLogin('admin')}
            className="w-full py-4 bg-transparent border border-cyber-neon/30 hover:bg-cyber-neon/10 text-cyber-neon font-mono rounded transition flex items-center justify-center gap-3"
          >
             <LayoutDashboard />
             ADMINISTRATOR
          </button>
        </div>

        <div className="mt-8 text-center text-xs text-gray-600 font-mono">
          SECURE CONNECTION :: ENCRYPTED
        </div>
      </div>
    </div>
  );
};

// --- Main App Component ---

const App: React.FC = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [user, setUser] = useState<User | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isSDKOpen, setIsSDKOpen] = useState(false);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const clearCart = () => setCart([]);

  const login = (role: 'user' | 'admin') => {
    setUser({
      id: role === 'admin' ? 'A-001' : 'U-1337',
      name: role === 'admin' ? 'Admin_X' : 'Neo_User',
      email: 'user@cldcde.cc',
      role
    });
  };

  const logout = () => setUser(null);

  return (
    <AppContext.Provider value={{ cart, addToCart, removeFromCart, updateQuantity, clearCart, user, login, logout, isCartOpen, setIsCartOpen, isSDKOpen, setIsSDKOpen }}>
      <Router>
        <div className="bg-black min-h-screen text-gray-200 selection:bg-cyber-blue selection:text-black font-sans">
          <Navbar />
          <CartDrawer />
          <SDKPanel isOpen={isSDKOpen} onClose={() => setIsSDKOpen(false)} />
          <AIChat />
          
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/login" element={<Login />} />
          </Routes>
          
          {/* Footer */}
          <footer className="border-t border-neutral-900 bg-black py-12 mt-20">
            <div className="max-w-7xl mx-auto px-4 text-center">
              <p className="font-term text-3xl font-bold text-white mb-4 tracking-widest">CLD<span className="text-cyber-neon">CDE</span></p>
              <p className="text-gray-600 text-sm font-mono mb-6">
                &copy; 2024 CLDCDE.CC<br/>
                PREMIUM ASSETS FOR THE DIGITAL FRONTIER
              </p>
              <div className="flex justify-center gap-6 text-gray-500 text-sm">
                <a href="#" className="hover:text-cyber-blue transition">TERMS</a>
                <a href="#" className="hover:text-cyber-blue transition">PRIVACY</a>
                <a href="#" className="hover:text-cyber-blue transition">SUPPORT</a>
              </div>
            </div>
          </footer>
        </div>
      </Router>
    </AppContext.Provider>
  );
};

export default App;