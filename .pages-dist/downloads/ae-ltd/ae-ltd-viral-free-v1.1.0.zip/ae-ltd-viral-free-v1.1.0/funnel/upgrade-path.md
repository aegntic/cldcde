# Upgrade Path: AE.LTD Viral Free

## Free-to-Pro Funnel
1. User installs free pack and gets first win in under 10 minutes.
2. User shares generated artifacts/workflows on X with pack attribution.
3. User hits scale limits (team rollout, deeper MCP graph, advanced automation).
4. User upgrades to pro at: https://ae.ltd/pro

## Conversion Triggers
- Need team-level rollout and governance.
- Need full plugin and MCP coverage.
- Need white-label packaging and advanced launch orchestration.
