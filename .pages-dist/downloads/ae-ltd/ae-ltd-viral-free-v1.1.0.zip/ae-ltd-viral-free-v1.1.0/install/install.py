#!/usr/bin/env python3
import argparse
import shutil
from pathlib import Path

PACK_ID = "ae-ltd-viral-free"
VERSION = "1.1.0"

def copy_tree(src: Path, dst: Path) -> None:
    dst.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        target = dst / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)

def main() -> None:
    parser = argparse.ArgumentParser(description="Install AE.LTD bundle")
    parser.add_argument("--prefix", default=str(Path.home() / ".ae-ltd" / PACK_ID), help="Install prefix")
    parser.add_argument("--install-skills", action="store_true", help="Install bundled skills into ~/.codex/skills")
    parser.add_argument("--install-zeroclaw", action="store_true", help="Install skills into ~/.zeroclaw/workspace/skills and ~/.clawreform/workspace/skills")
    parser.add_argument("--install-agent-zero", action="store_true", help="Install skills into agent-zero skills directory")
    parser.add_argument("--agent-zero-path", default=str(Path.home() / "agent-zero-data" / "skills"), help="Agent Zero skills directory")
    args = parser.parse_args()

    script_dir = Path(__file__).resolve().parent
    pack_root = script_dir.parent
    bundle = pack_root / "bundle"
    prefix = Path(args.prefix)

    if prefix.exists():
        shutil.rmtree(prefix)
    copy_tree(bundle, prefix)

    print(f"[OK] Installed {PACK_ID} v{VERSION} to {prefix}")

    skills_src = bundle / "skills"

    if args.install_skills and skills_src.exists():
        codex_skills = Path.home() / ".codex" / "skills"
        codex_skills.mkdir(parents=True, exist_ok=True)
        copy_tree(skills_src, codex_skills)
        print(f"[OK] Installed skills to {codex_skills}")

    if args.install_agent_zero and skills_src.exists():
        agent_zero = Path(args.agent_zero_path).expanduser()
        agent_zero.mkdir(parents=True, exist_ok=True)
        copy_tree(skills_src, agent_zero)
        print(f"[OK] Installed skills to {agent_zero}")

    if args.install_zeroclaw and skills_src.exists():
        targets = [
            Path.home() / ".zeroclaw" / "workspace" / "skills",
            Path.home() / ".clawreform" / "workspace" / "skills",
        ]
        for target in targets:
            target.mkdir(parents=True, exist_ok=True)
            copy_tree(skills_src, target)
            print(f"[OK] Installed skills to {target}")

    print("[DONE] Install complete")

if __name__ == "__main__":
    main()
