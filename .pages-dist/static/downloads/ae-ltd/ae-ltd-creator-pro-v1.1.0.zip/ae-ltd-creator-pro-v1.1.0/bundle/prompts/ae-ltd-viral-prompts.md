# AE.LTD Viral Prompt Set

1. Design a launch loop where each generated artifact recruits one more user.
2. Convert this feature list into a free wow moment plus paid unlock path.
3. Generate a seven-post X thread that teaches one hard skill and converts cleanly.
4. Refactor this MCP toolset so a beginner gets first success in under five minutes.
5. Turn this changelog into a release story optimized for reposts and quote tweets.
6. Create a referral mechanic where exports carry tasteful branding and one-click install metadata.
